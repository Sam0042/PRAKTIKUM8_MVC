<?php
defined('BASEPATH') OR exit('No direct script access allowe
d');
class BMI extends CI_Controller {

    public function index() {
        $this->load->model('pasien_model','pasien1');
        $this->pasien1->id=1;
        $this->pasien1->kode='001';
        $this->pasien1->nama='Hanna Balqis';
        $this->pasien1->tmp_lahir='Padang';
        $this->pasien1->tgl_lahir='19 Agustus 2000';
        $this->pasien1->gender='P';
        
        $this->load->model('pasien_model','pasien2');
        $this->pasien2->id=2;
        $this->pasien2->kode='002';
        $this->pasien2->nama='Ahmad Fauzi';
        $this->pasien2->tmp_lahir='Bogor';
        $this->pasien2->tgl_lahir='9 Oktober 2002';
        $this->pasien2->gender='L';

        $this->load->model('pasien_model','pasien3');
        $this->pasien3->id=3;
        $this->pasien3->kode='003';
        $this->pasien3->nama='Hisyam Mubarak';
        $this->pasien3->tmp_lahir='Jakarta';
        $this->pasien3->tgl_lahir='21 Maret 2002';
        $this->pasien3->gender='L';

//=========================================================
        $this->load->model('bmipasien_model', 'bmipasien1');
        $this->bmipasien1->id=1;
        $this->bmipasien1->tanggal='2021-11-02';
        $this->bmipasien1->pasien='Faiz Fikri';
        $this->bmipasien1->bmi='';

        $this->load->model('bmipasien_model', 'bmipasien2');
        $this->bmipasien2->id=2;
        $this->bmipasien2->tanggal='2021-09-10';
        $this->bmipasien2->pasien='Pandan Wangi';
        $this->bmipasien2->bmi='';

        $this->load->model('bmipasien_model', 'bmipasien3');
        $this->bmipasien3->id=3;
        $this->bmipasien3->tanggal='2021-08-19';
        $this->bmipasien3->pasien='Hisyam Mubarak';
        $this->bmipasien3->bmi='';

//=========================================================
        $this->load->model('bmi_model', 'bmi1');
        $this->bmi1->berat=60.5;
        $this->bmi1->tinggi=175;
        $this->bmi1->nilaiBMI(); // sebenernya cukup ini aja gausa kasih di bmi2 3
        $this->bmi1->statusBMI(); // ini

        $this->load->model('bmi_model', 'bmi2');
        $this->bmi2->berat=80;
        $this->bmi2->tinggi=168;
        // $this->bmi1->nilaiBMI(); 
        // $this->bmi1->statusBMI();
        
        $this->load->model('bmi_model', 'bmi3');
        $this->bmi3->berat=51;
        $this->bmi3->tinggi=171;
        // $this->bmi1->nilaiBMI(); 
        // $this->bmi1->statusBMI();
        
        $list_pasien = [$this->pasien1, $this->pasien2, $this->pasien3];
        $list_bmipasien = [$this->bmipasien1, $this->bmipasien2, $this->bmipasien3];
        $list_bmi = [$this->bmi1, $this->bmi2, $this->bmi3];
        
        $data['list_pasien']=$list_pasien;
        $data['list_bmipasien']=$list_bmipasien;
        $data['list_bmi']=$list_bmi;
        
        $this->load->view('layouts/header');
        $this->load->view('bmi/index', $data);
        $this->load->view('layouts/footer');
    }
}
?>